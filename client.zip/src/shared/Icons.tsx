import type { SVGProps } from "react";

export const DrinkIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="#6A689A"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M10 2v2" />
    <path d="M14 2v2" />
    <path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1" />
    <path d="M6 2v2" />
  </svg>
);

// آیکون‌های بعدی
export const DessertIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg {...props}>
    {/* SVG */}
  </svg>
);

export const BreakfastIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg {...props}>
    {/* SVG */}
  </svg>
);
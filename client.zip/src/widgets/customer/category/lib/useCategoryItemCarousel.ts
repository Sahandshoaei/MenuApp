import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useMenu } from "@/entities/menu/hooks/useMenu";

export const useCategoryItemCarousel = () => {
  const navigate = useNavigate();
  const { categoryId, itemId } = useParams();
  const { menu, getCategory } = useMenu();

  const items = useMemo(
    () => menu.filter((item) => item.category === categoryId),
    [menu, categoryId]
  );

  const category = categoryId ? getCategory(categoryId) : undefined;

  const initialIndex = useMemo(() => {
    if (!itemId) return 0;
    const index = items.findIndex((item) => item.id === itemId);
    return index === -1 ? 0 : index;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoryId]);

  const [activeIndex, setActiveIndex] = useState(initialIndex);
  const scrollRef = useRef<HTMLDivElement>(null);

  // وقتی دسته‌بندی عوض بشه (رفتن به یه صفحه‌ی دسته‌بندی دیگه)، index ریست بشه
  useEffect(() => {
    setActiveIndex(initialIndex);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoryId]);

  // وقتی کاربر با اسکرول/سوایپ آیتم فعال رو عوض کرد، URL هم sync بشه
  // (بدون اضافه کردن رکورد جدید به تاریخچه‌ی مرورگر)
  useEffect(() => {
    const current = items[activeIndex];
    if (current && current.id !== itemId) {
      navigate(`/category/${categoryId}/${current.id}`, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeIndex, items]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el || items.length === 0) return;

    const cardWidth = el.scrollWidth / items.length;
    const index = Math.round(el.scrollLeft / cardWidth);
    const clamped = Math.min(Math.max(index, 0), items.length - 1);

    if (clamped !== activeIndex) setActiveIndex(clamped);
  };

  return {
    category,
    items,
    activeItem: items[activeIndex],
    activeIndex,
    scrollRef,
    handleScroll,
  };
};
